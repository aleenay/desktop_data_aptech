XML
1 - XML is user to exchange data or structure data.
2 - XML uses user defined tags. XML  does not have predefined tags.
3 - XML tags are case sensitive.
4 - XML tags must be closed otherwise you will get an error.
5 - XML is a strict language
6 - XML file must have .xml extension

HTML (Hypertext Markup Language)
1 - HTML is used to structure a webpage
2 - HTML tags are predefined.
3 - HTML tags are case insensitive 
4 - HTML tags should also be closed but browser won't mind if you forget to close any tag.
5 - HTML is not a strict language



XSD = XML Schema Defination/Language


